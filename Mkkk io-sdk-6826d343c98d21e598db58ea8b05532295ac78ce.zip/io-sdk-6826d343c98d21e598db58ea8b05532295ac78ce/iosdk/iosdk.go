package main

// Version is the current version - it will be set when built
var Version = "master"

//main
func main() {
	Main(Version)
}
