# Prerequisites

Supported development platforms are:
- Linux Ubuntu 18.x and 20.x

Also your workstation needs at least 8gb of memory.

It may work on other configurations but it is not tested.

You need to install docker [as described here](https://docs.docker.com/engine/install/ubuntu/).

Before doing anything, you have to [setup your environment](./../../../DEVEL.md#First-setup-of-the-development-environment).