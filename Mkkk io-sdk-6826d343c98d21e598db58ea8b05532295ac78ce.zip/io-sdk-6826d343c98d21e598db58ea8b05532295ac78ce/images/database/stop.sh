docker-compose rm -s -f
