# ide-plugin
ide-plugin Plugin example for Theia.
