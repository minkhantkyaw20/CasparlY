source "$(dirname $0)/util.bash"
function run { $* }
setup
