process.env.JEST_PLAYWRIGHT_CONFIG = "jest-playwright.debug.js"
module.exports = {
  verbose: true,
  preset: 'jest-playwright-preset'
}
