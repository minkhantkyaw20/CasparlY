# Backend

Before running, build images with make at top level

Use:

- `make start` to start development server
- `make devel` to develop front-end
- `make deploy` to deploy or update images
- `make stop` to stop development server
