function main(args) {
    return { "body": { "form": [ {
            "type": "message",
            "name": "note",
            "description": "Please use the Development menu to edit and deploy a custom importer."
        } ] }
    }
}
