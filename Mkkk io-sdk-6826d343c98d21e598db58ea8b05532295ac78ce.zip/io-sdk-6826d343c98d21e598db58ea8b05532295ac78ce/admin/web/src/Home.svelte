<div class="it-hero-wrapper">
  <div class="container-fluid">
    <div class="row">
        <div class="col-9">
          <div class="it-hero-text-wrapper bg-dark">
              <span class="it-category">Welcome</span>
              <h1 class="no_toc">IO-SDK</h1>
              <p class="d-none d-lg-block">Welcome to the development kit to easily build importers for the app IO.</p>
          </div>
        </div>
    </div>
  </div>
</div>
