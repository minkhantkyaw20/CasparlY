 <nav class="navbar navbar-expand-lg">
  <div class="collapse show navbar-collapse navbar-collapsable" style="position: relative; display: block;">
    <ul class="justify-content-between navbar-nav">
      <section>
       <ul class="nav">
        <li class="nav-item">    
           <a href="/" class="nav-link">
            <span><i class="fas fa-home"></i>&nbsp;</span>IO-SDK
           </a>
        </li>
      </ul>
      </section>
      <section>
        <ul class="nav">
          <li class="d-flex nav-item">
            <div class="text-white align-self-center">
              <a target="_blank" class="nav-link" href="https://developer.io.italia.it/openapi.html">API IO</a>
            </div>
          </li>
          <li class="d-flex nav-item">
            <div class="text-white align-self-center">
              <a target="_blank" class="nav-link" href="https://github.com/pagopa/io-sdk">GitHub</a>
            </div>
          </li>
        </ul>
      </section>
    </ul>
  </div>
</nav>

