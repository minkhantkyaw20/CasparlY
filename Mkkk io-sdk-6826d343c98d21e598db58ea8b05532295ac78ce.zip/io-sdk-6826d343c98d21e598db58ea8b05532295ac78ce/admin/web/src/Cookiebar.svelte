<div class="cookiebar bg-dark p-4 hide" aria-hidden="true">
  <div class="container">
    <div class="row d-flex align-items-center">
      <div class="col-12 col-md-6">
        <span class="text-white small">Questo sito utilizza cookie tecnici, analytics e di terze parti.<br>Proseguendo nella navigazione accetti l’utilizzo dei cookie.</span>
      </div>
      <div class="col-12 col-md-6 mt-4 mt-md-0 d-flex justify-content-end">
        <a class="btn btn-link" href="https://designers.italia.it/privacy-policy/">Privacy policy</a>
        <button class="btn btn-primary mr-2" data-accept="cookiebar">Accetto</button>
      </div>
    </div>
  </div>
</div>